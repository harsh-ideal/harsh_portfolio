import React, { useState, useRef, lazy, Suspense } from "react";
import { motion } from "framer-motion";
import emailjs from "@emailjs/browser";
import { styles } from "../style";

import { SectionWrapper } from "../hoc";
import { slideIn } from "../utils/motion";
import useIsMobile from "../hooks/useIsMobile";
import earthImg from "../assets/earth_transparent.webp";

const EarthCanvas = lazy(() => import("./canvas/Earth"));


//template Id  template_rm6jdzg

//service id   service_7u7izzf

//public key   Bc9zEfB1jLMAMpl1cX6Ia

const Contact = () => {
  const formRef = useRef();
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [loading, setLoading] = useState(false);
  const isMobile = useIsMobile();

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    setLoading(true);

    emailjs
      .send(
        "service_7u7izzf",
        "template_rm6jdzg",
        {
          from_name: form.name,
          to_name: "Harsh Srivastava",
          from_email: form.email,
          to_email: "harshideal2002@gmail.com",
          message: form.message,
        },
        "uDUh5PZOwgZZuZ0L2"
      )
      .then(
        () => {
          setLoading(false);
          alert("Thank You, I will get back tou as soon as possible.");

          setForm({
            name: "",
            email: "",
            message: "",
          });
        },
        (error) => {
          setLoading(false);

          console.log(error);

          alert("something went wrong, Please try again");
        }
      );
  };

  return (
    <div className="xl:mt-12 xl:flex-row  flex-col-reverse flex gap-10 overflow-hidden">
      <motion.div
        variants={slideIn("left", "tween", 0.2, 1)}
        className=" flex-[0.75] bg-black-100 p-8 rounded-2xl"
      >
        <p className={`${styles.sectionSubText}`}>Get in Touch</p>
        <h3 className={styles.sectionHeadText}>Contact.</h3>

        <form
          ref={formRef}
          onSubmit={handleSubmit}
          className="mt-12 flex flex-col gap-8"
        >
          <label className="flex flex-col">
            <span className="text-white font-medium mb-4">Your Name</span>
            <input
              type="text"
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Whats your Name"
              className="bg-tertiary py-4 px-6 placeholder:text-secondary rexr-white rounded-lg outlined-none border-none font-medium"
            />
          </label>
          <label className="flex flex-col">
            <span className="text-white font-medium mb-4">Your Email</span>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Whats your Email"
              className="bg-tertiary py-4 px-6 placeholder:text-secondary rexr-white rounded-lg outlined-none border-none font-medium"
            />
          </label>
          <label className="flex flex-col">
            <span className="text-white font-medium mb-4">Your Message</span>
            <textarea
              rows="7"
              name="message"
              value={form.message}
              onChange={handleChange}
              placeholder="Whats do you wabt to say ?"
              className="bg-tertiary py-4 px-6 placeholder:text-secondary rexr-white rounded-lg outlined-none border-none font-medium"
            />
          </label>

          <button
            type="submit"
            className="bg-tertiary py-3 px-8 outine-none w-fit text-white font-bold shadow-md  shadow-primary rounded-xl"
          >
            {loading ? "Sending..." : "Send"}
          </button>
        </form>
      </motion.div>

      <motion.div
        variants={slideIn("right", "tween", 0.2, 1)}
        className="xl:flex-1 xl:h-auto md:h-[550px] h-[350px]"
      >
        {isMobile ? (
          <img
            src={earthImg}
            alt="3D model placeholder"
            className="w-[75%] mx-auto h-full object-contain"
          />
        ) : (

          <Suspense fallback={<div></div>}>
                       <EarthCanvas />
          </Suspense>
        )}
      </motion.div>
    </div>
  );
};

export default SectionWrapper(Contact, "contact");
