import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { styles } from "../style.js";
import { navLinks } from "./../constants/index";
import { logo, menu, close, profile, Resume } from "../assets/index.js";
import linkedinIcon from "../assets/LinkedIn_icon.svg.webp"
import githubIcon from "../assets/github.webp"
import useIsMobile from './../hooks/useIsMobile';

const Navbar = () => {
  const [active, setActive] = useState("");
  const [toggle, setToggle] = useState(false);
  const isMobile=useIsMobile()
  return (
    <nav
      className={`${styles.paddingX} w-full flex item-center py-5 fixed top-0 z-20 bg-primary`}
    >
      <div className="w-full flex justify-between item-center man-w-7xl mx-auto">
        <div className="flex gap-5">
        <Link
          to="/"
          className="flex item-center gap-2"
          onClick={() => {
            setActive("");
            window.scrollTo(0, 0);
          }}
        >
          <img src={profile} alt="logo" className="w-9 h-9 rounded-full object-contain" />
          <p className="text-white text-[18px] font-bold cursor-pointer flex">
            Harsh Srivastva &nbsp;
            <span className="sm:block hidden">| Software Developer</span>
          </p>
        </Link>
      {!isMobile && <> <a href={"https://www.linkedin.com/in/harsh-srivastava21/"} target="_blank" rel="noopener noreferrer"><img src={linkedinIcon} width={25} alt="Linked"/></a>
        <a href={"https://github.com/harsh-ideal"} target="_blank" rel="noopener noreferrer"><img src={githubIcon} alt="Github" width={28}/></a>
        <a href={"https://drive.google.com/file/d/1HKDMS8CKybUSC0p7wLlbzxSK9iPR3mNo/view?usp=sharing"} target="_blank" rel="noopener noreferrer"><img src={Resume} alt="Resume" width={45}/></a>

   </>}
        </div>
        
            <ul className="list-none hidden sm:flex flex-row gap-10">
          {navLinks.map((link) => (
            <li
              key={link.id}
              className={`${
                active === link.title ? "text-white" : "text-secondary"
              } hover:text-white text-[18px] font-medium cursor-pointer`}
              onClick={() => setActive(link.title)}
            >
              <a href={`#${link.id}`}>{link.title}</a>
            </li>
          ))}
        </ul>
        <div className="sm:hidden flex flex-1 justify-end item-center">
          <img
            src={toggle ? close : menu}
            alt="menu"
            className="w-[28px] h-[28px] object-contain cursor-pointer"
            onClick={() => setToggle(!toggle)}
          />
          <div
            className={`${
              !toggle ? "hidden" : "flex"
            } p-6 black-gradient absolute top-20 right-0 mx-4 my-2 min-w-[140px] z-10 rounded-xl`}
          >
            <ul className="list-none flex justify-end item-start flex-col gap-4">
              {navLinks.map((link) => (
                <li
                  key={link.id}
                  className={`${
                    active === link.title ? "text-white" : "text-secondary"
                  } font=poppins font-medim cursor-pointer text-[16px]  `}
                  onClick={() => {
                    setActive(link.title);
                    setToggle(!toggle);
                  }}
                >
                  <a href={`#${link.id}`}>{link.title}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
     
    </nav>
  );
};

export default Navbar;
